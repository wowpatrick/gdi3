#ifndef GLOBALS_HEADER
#define GLOBALS_HEADER

#define WIDTH 1024
#define HEIGHT 768
#define RADIUS 2
#define ZOOM 0.4f
#define INITIAL_UPPERLEFT (-2.5+1.5*I)
#define INITIAL_LOWERRIGHT (1-1.5*I)

#endif /* GLOBALS_HEADER */
