#include "mandelbrot.h"
#include <xmmintrin.h>

float _Complex
cSqr(float _Complex a)
{
    float real = crealf(a);
    float imag = cimagf(a);
    return (real*real-imag*imag) + (2*real*imag) * _Complex_I;
}


float _Complex
cAdd(float _Complex a, float _Complex b)
{
    float reala = crealf(a);
    float imaga = cimagf(a);
    
    float realb = crealf(b);
    float imagb = cimagf(b);
    
    return (reala + realb) + (imaga + imagb) * _Complex_I;
}

float
cBetrag(float _Complex a)
{
    float real = crealf(a);
    float imag = cimagf(a);
    return  sqrt(real*real+imag*imag);
}




void
colorMapYUV(int *index, int maxIterations, unsigned char* color)
{
    /*	if (
     index[0]==maxIterations &&
     index[1]==maxIterations &&
     index[2]==maxIterations &&
     index[3]==maxIterations){
     for (int i = 0; i < 4; i++){
     color [i*3]   =  0;
     color [i*3+1] =  0;
     color [i*3+2] =  0;
     }
     return;
     }
     */
    
	// initialization of index and max iterations
    __m128 index_m128 = _mm_set_ps((float)index[3], (float)index[2], (float)index[1], (float)index[0]);
	float maxIterationf = (float) maxIterations;
    __m128 maxIteration_m128 = _mm_load1_ps(&maxIterationf);
    
	// mask used to cover black pixel
    __m128 mask = _mm_cmpeq_ps(index_m128, maxIteration_m128);
	__m128 zero = _mm_setzero_ps();
	__m128 neg_mask = _mm_cmpeq_ps (mask, zero);
    
    // calculation of yuv
	float yuv_constant [4] = {2.0, 1.0, 0.5, 0.2};
    __m128 q_m128 = _mm_load1_ps(yuv_constant);
    __m128 q1_m128 = _mm_load1_ps(yuv_constant + 1);
    __m128 q2_m128 = _mm_load1_ps(yuv_constant + 2);
    
    __m128 y_m128 = _mm_load1_ps(yuv_constant + 3);
    __m128 u_m128 = _mm_sub_ps(_mm_mul_ps(_mm_div_ps(index_m128, maxIteration_m128), q_m128), q1_m128);
    __m128 v_m128 = _mm_sub_ps(q2_m128, _mm_div_ps(index_m128, maxIteration_m128));
    
    // calculation of rgb
	float rgb_constant [5] = {1.28033, 255.0, -0.21482, -0.38059, 2.12798};
    __m128 a_m128 = _mm_load1_ps(rgb_constant);
    __m128 a1_m128 = _mm_load1_ps(rgb_constant + 1);
    __m128 a2_m128 = _mm_load1_ps(rgb_constant + 2);
    __m128 a3_m128 = _mm_load1_ps(rgb_constant + 3);
    __m128 a4_m128 = _mm_load1_ps(rgb_constant + 4);
    
    // r = 255 * (y + (1.28033 * v))
    __m128 r_m128 = _mm_mul_ps(a1_m128,_mm_add_ps(y_m128,_mm_mul_ps(a_m128,v_m128)));
	r_m128 = _mm_and_ps (neg_mask, r_m128);
    // g = 255 * (y + (-0.21482 * u) + (-0.38059 * v));
    __m128 g_m128 = _mm_mul_ps(a1_m128,_mm_add_ps(_mm_mul_ps(a3_m128, v_m128),_mm_add_ps(y_m128, _mm_mul_ps(a2_m128, u_m128))));
	g_m128 = _mm_and_ps (neg_mask, g_m128);
    // b = 255 * (y + (2.12798 * u))
    __m128 b_m128 = _mm_mul_ps(a1_m128,_mm_add_ps(y_m128,_mm_mul_ps(a4_m128, u_m128)));
	b_m128 = _mm_and_ps (neg_mask, b_m128);
    
    float red [4] = {0};
    float green [4] = {0};
    float blue [4] = {0};
    
    _mm_storeu_ps (red,  r_m128);
    _mm_storeu_ps (green,g_m128);
    _mm_storeu_ps (blue, b_m128);
    
    for (int i = 0; i < 4; i++){
		color [i*3]   =  (unsigned char) red[i];
		color [i*3+1] =  (unsigned char) green[i];
		color [i*3+2] =  (unsigned char) blue[i];
    }
    
}
int*
testEscapeSeriesForPoint(complex float *c, int maxIterations, complex float *last)
{
    
    int iteration [4] = {0};
    int* pIteration = iteration;
    
    
    
    
    
    char fullcondition = {iteration[0] < maxIterations && iteration[1] < maxIterations && iteration[2] < maxIterations && iteration[3] < maxIterations &&
        cBetrag(last[0]) <= RADIUS && cBetrag(last[1]) <= RADIUS && cBetrag(last[2]) <= RADIUS && cBetrag(last[3]) <= RADIUS};
    
    __m128 real_last_m128, imag_last_m128;
    
    
    
    while (fullcondition){
        float test1 [4]= {0};
        
        //printf("real von last: %f %f %f %f\n", crealf(last[0]), crealf(last[1]), crealf(last[2]), crealf(last[3]));
        //printf("imag von last: %f %f %f %f\n", cimagf(last[0]), cimagf(last[1]), cimagf(last[2]), cimagf(last[3]));
        
        real_last_m128 = _mm_set_ps(crealf(last[3]), crealf(last[2]), crealf(last[1]), crealf(last[0]));
        imag_last_m128  = _mm_set_ps(cimagf(last[3]), cimagf(last[2]), cimagf(last[1]), cimagf(last[0]));
        
        // Setting all 4 lasts because the condition is fulfilled by all 4
        __m128 sqrReal_last_m128 = _mm_sub_ps(_mm_mul_ps(real_last_m128, real_last_m128), _mm_mul_ps(imag_last_m128, imag_last_m128));
        float two = 2;
        __m128 two_m128 = _mm_load1_ps(&two);
        __m128 sqrImag_last_m128 = _mm_mul_ps(two_m128, _mm_mul_ps(real_last_m128, imag_last_m128));
        
        _mm_storeu_ps(test1, sqrReal_last_m128);
        //printf("sqr von real: %f %f %f %f\n", test1[0], test1[1], test1[2], test1[3]);
        _mm_storeu_ps(test1, sqrImag_last_m128);
        //printf("sqr von imag: %f %f %f %f\n", test1[0], test1[1], test1[2], test1[3]);
        
        __m128 cReal = _mm_set_ps(crealf(c[3]), crealf(c[2]), crealf(c[1]), crealf(c[0]));
        __m128 cImag = _mm_set_ps(cimagf(c[3]), cimagf(c[2]), cimagf(c[1]), cimagf(c[0]));
        
        __m128 result_last_Real_m128 = _mm_add_ps(sqrReal_last_m128, cReal);
        __m128 result_last_Imag_m128 = _mm_add_ps(sqrImag_last_m128, cImag);
        
        float imag_last [4] = {0};
        float real_last [4] = {0};
        
        _mm_storeu_ps(imag_last, result_last_Imag_m128);
        _mm_storeu_ps(real_last, result_last_Real_m128);
        
        for (int j = 0; j < 4; j++){
            last [j] = real_last[j] + imag_last[j] *  _Complex_I;
            iteration[j]++;
        }
        
        fullcondition = iteration[0] < maxIterations && iteration[1] < maxIterations && iteration[2] < maxIterations && iteration[3] < maxIterations &&
        cBetrag(last[0]) <= RADIUS && cBetrag(last[1]) <= RADIUS && cBetrag(last[2]) <= RADIUS && cBetrag(last[3]) <= RADIUS;
    }
    
    for (int i = 0 ; i < 4; i++){
        while (cBetrag (last[i]) <= RADIUS && iteration[i] < maxIterations){
            last[i] = cAdd (cSqr(last[i]) , c[i]);
            iteration[i]++;
        }
    }
    
    
    
    return pIteration;
}



unsigned char *
generateMandelbrot(
                   complex float upperLeft,
                   complex float lowerRight,
                   int maxIterations,
                   int width,
                   int height)
{
    unsigned char *image = malloc(height * width * 3);
    
    
    
    float CxMin = crealf(upperLeft);
    float CxMax = crealf(lowerRight);
    float CyMin = cimagf(lowerRight);
    float CyMax = cimagf(upperLeft);
    
    for(int y = 0; y < height; y = y + 4) {
		__m128 y_m128 = _mm_set_ps( (float) y+3, (float) y+2, (float) y+1, (float) y);
		__m128 cyMin_m128 = _mm_load1_ps(&CyMin);
		__m128 cyMax_m128 = _mm_load1_ps(&CyMax);
		__m128 height_m128 = _mm_set_ps((float)height, (float) height, (float) height, (float)height);
		__m128 im_m128 =  _mm_add_ps(cyMin_m128, _mm_mul_ps(y_m128, _mm_div_ps (_mm_sub_ps(cyMax_m128, cyMin_m128), height_m128)));
		float im_teila [4] = {0};
		_mm_storeu_ps (im_teila, im_m128);
        
		for (int j = 0; j < 4; j++){
			float im_teil = im_teila[j];
            
            for(int x = 0; x < width; x = x + 4) {
                __m128 cxMax_m128 = _mm_load1_ps(&CxMax);
                __m128 cxMin_m128 = _mm_load1_ps(&CxMin);
                __m128 width_m128 = _mm_set_ps((float)width, (float)width, (float)width, (float)width);
                __m128 x_m128 = _mm_set_ps((float) x+3, (float) x+2, (float) x+1, (float) x);
                
                __m128 rl_m128 = _mm_add_ps(cxMin_m128, _mm_mul_ps(x_m128, _mm_div_ps (_mm_sub_ps(cxMax_m128, cxMin_m128), width_m128)));
                
                
                float rl_teil [4] = {0};
                _mm_storeu_ps (rl_teil,rl_m128);
                
                float _Complex c0 = rl_teil[0] + im_teil * _Complex_I;
                float _Complex c1 = rl_teil[1] + im_teil * _Complex_I;
                float _Complex c2 = rl_teil[2] + im_teil * _Complex_I;
                float _Complex c3 = rl_teil[3] + im_teil * _Complex_I;
                
                float _Complex c [4] = {c0, c1, c2, c3};
                float _Complex z = 0 + 0 * _Complex_I;
				float _Complex z_array[4] = {z,z,z,z};
				float _Complex *pointz = z_array;
                float _Complex *pointc = c;
				/*
                 printf ("Calculating Iterations for x = %d and y = %d\n", x, y);
                 printf ("Input Max-Iterations:\n\t %d\n", maxIterations);
                 printf ("Input Complex numbers c:\n\t %f + %f * i \n\t %f + %f * i \n\t %f + %f * i \n\t %f + %f * i \n",
                 crealf(pointc[0]), cimagf(pointc[0]), crealf(pointc[1]), cimagf(pointc[1]), crealf(pointc[2]), cimagf(pointc[2]), crealf(pointc[3]), cimagf(pointc[3]));
                 printf ("Input Complex numbers z:\n\t %f + %f * i \n\t %f + %f * i \n\t %f + %f * i \n\t %f + %f * i \n",
                 crealf(pointz[0]), cimagf(pointz[0]), crealf(pointz[1]), cimagf(pointz[1]), crealf(pointz[2]), cimagf(pointz[2]), crealf(pointz[3]), cimagf(pointz[3]));
                 */
				int *iteration_needed =  testEscapeSeriesForPoint(pointc, maxIterations, pointz);
                
				/*
                 if (y== 230 && x == 240){
                 printf ("Output Iterations:\n");
                 printf("\t%f, %f, %f, %f\n",iteration_needed[0], iteration_needed[1], iteration_needed[2], iteration_needed[3]);
                 printf ("------------------------------\n\n");
                 }
                 */
                
                
                
                
				for (int i = 0; i < 4; i++){
					if (iteration_needed[i] < maxIterations){
						float mu = log (log (cBetrag(z_array[i]))/ log(2)) / log(2);
						iteration_needed[i] = iteration_needed[i] + 1 - mu;
					}
				}
                
				int offset = ((y+j) * width + x) * 3;
                colorMapYUV(iteration_needed, maxIterations, image + offset);
                
            }
            
		}
        
    }
    
    
    return image;
}

